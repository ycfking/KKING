package com.baidu.location.demo.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.baidu.location.demo.R;

// 1. 继承自某个ViewGroup
public class ParamSetView extends FrameLayout {
    // 2.1 定义属性
    private int mCurrentValue;
    private int mPrevValue;
    private TextView minusBtn;
    private TextView plusBtn;
    private EditText et_value;
    private TextView tv_display;
    private OnValueChangeListener listener;
    private int mMax;
    private int mMin;
    private int mStep;
    private boolean mDisable;
    private int mDefValue;
    private String display;


    public ParamSetView(@NonNull Context context) {
        this(context, null);
    }

    public ParamSetView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ParamSetView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        LayoutInflater.from(context).inflate(R.layout.view_param_set, this, true);
        initView(context);
        initAttrs(attrs, context);
        setUpEvent();
    }

    // 2.2 获取属性
    private void initAttrs(AttributeSet attrs, Context context) {
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.InputNumView);
        mMax = a.getInt(R.styleable.InputNumView_max, 100);
        mMin = a.getInt(R.styleable.InputNumView_min, 0);
        mDefValue = a.getInt(R.styleable.InputNumView_defValue, 0);
        mStep = a.getInt(R.styleable.InputNumView_step, 3);
        mDisable = a.getBoolean(R.styleable.InputNumView_disable, false);
        display = a.getString(R.styleable.InputNumView_display);

        mCurrentValue = mDefValue;
        updateValueText();
    }

    // 4. 处理事件
    private void setUpEvent() {
        minusBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                mPrevValue = mCurrentValue;
                mCurrentValue -= mStep;
                if (mCurrentValue < mMin) {
                    mCurrentValue = mMin;
                }
                if (mPrevValue != mCurrentValue) {
                    if (listener != null) {
                        listener.onValueChange(mCurrentValue);
                    }
                    updateValueText();
                }
            }
        });
        plusBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                mPrevValue = mCurrentValue;
                mCurrentValue += mStep;
                if (mCurrentValue > mMax) {
                    mCurrentValue = mMax;
                }
                if (mPrevValue != mCurrentValue) {
                    if (listener != null) {
                        listener.onValueChange(mCurrentValue);
                    }
                    updateValueText();
                }
            }
        });

        minusBtn.setEnabled(!mDisable);
        plusBtn.setEnabled(!mDisable);
    }

    private void updateValueText() {
        et_value.setText(String.valueOf(mCurrentValue));
        tv_display.setText(display);
    }

    // 3. 加载组合的View
    private void initView(Context context) {
        // 任何的view都可以设置点击事件
        minusBtn = findViewById(R.id.minus_tv);
        plusBtn = findViewById(R.id.plus_tv);
        et_value = findViewById(R.id.input_value_et);
        tv_display = findViewById(R.id.tv_display);
    }

    // 5. 对外暴露的接口
    public void setOnValueChangeListener(OnValueChangeListener listener) {
        this.listener = listener;
    }

    public int getValue() {
        return Integer.parseInt(et_value.getText().toString());
    }

    public interface OnValueChangeListener {
        void onValueChange(int value);
    }
}