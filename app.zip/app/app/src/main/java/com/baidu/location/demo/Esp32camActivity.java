package com.baidu.location.demo;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import com.baidu.location.demo.service.Constants;
import com.baidu.location.demo.service.Mqtt3Service;
import com.baidu.location.demo.service.esp32camService;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

/**
 * 定位图标指示方向示例demo
 */
public class Esp32camActivity extends AppCompatActivity {

    private static String action = "com.nicecode.mymqttservice";
    private static String TAG = "hello";

    private Handler handler = new Handler(Looper.getMainLooper());
    private ImageView iv_image;
    private Button btn_photo;
    private Bitmap bitmap;
    private Intent mIntent;
    private esp32camService.LocalBinder mBinder; // 声明一个粘合剂对象

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_esp32cam);

        iv_image = findViewById(R.id.iv_image);

        btn_photo = findViewById(R.id.btn_photo);

//        mIntent = new Intent(Esp32camActivity.this, esp32camService.class);
//        startService(mIntent);

        mIntent = new Intent(Esp32camActivity.this, esp32camService.class);
        boolean bindFlag = bindService(mIntent, serviceConnection, Context.BIND_AUTO_CREATE);

        /*************************通过广播接收的方式从MqttService中接收数据*************************/
        IntentFilter filter = new IntentFilter(Esp32camActivity.action);
        getApplicationContext().registerReceiver(Esp32camActivity_broadcastReceiver, filter);

        Log.d(TAG,"Esp32camActivity start");
        /*************************通过广播接收的方式从MqttService中接收数据*************************/


        btn_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ContextCompat.checkSelfPermission(Esp32camActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(Esp32camActivity.this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
                }else {
                    try {
                        saveImageToGallery(Esp32camActivity.this,bitmap);
                    } catch (FileNotFoundException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
    }
    /**
     * 保存bimap到相册
     */
    public void saveImageToGallery(Context context, Bitmap bmp) throws FileNotFoundException {
        // 首先保存图片 创建文件夹
        String file_name = System.currentTimeMillis() + ".jpg";
        File file = new File(getExternalFilesDir(null), file_name);

        try (FileOutputStream fos = new FileOutputStream(file)) {
            bmp.compress(Bitmap.CompressFormat.JPEG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 其次把文件插入到系统图库
        String path = file.getAbsolutePath();
        try {
            MediaStore.Images.Media.insertImage(context.getContentResolver(), path, file_name, null);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (SecurityException e) {
            e.printStackTrace();
        }
        // 最后通知图库更新
        try {
            MediaScannerConnection.scanFile(context, new String[]{file.getAbsolutePath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                @Override
                public void onScanCompleted(String path, Uri uri) {
                    Log.i("ExternalStorage", "Scanned " + path + ":");
                    Log.i("ExternalStorage", "-> uri=" + uri);
                }
            });
        } catch (SecurityException e) {
            e.printStackTrace();
        }
        Toast.makeText(context, "保存到相册", Toast.LENGTH_SHORT).show();
    }

    /**
     * 广播图像接收
     */
    public BroadcastReceiver Esp32camActivity_broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent msgintent) {

            byte[] img_byte = msgintent.getByteArrayExtra("MQTT_IMG");
            bitmap =BitmapFactory.decodeByteArray(img_byte,0,img_byte.length);
            runOnUiThread(() -> iv_image.setImageBitmap(bitmap));
        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "授权成功！！！", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "授权失败！！！", Toast.LENGTH_SHORT).show();
                }
                break;
            }
        }
    }

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBinder = (esp32camService.LocalBinder) service;
            Log.d(TAG, "esp32cam服务连接成功");
            mBinder.subscribe_message(Constants.sub_topic);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}