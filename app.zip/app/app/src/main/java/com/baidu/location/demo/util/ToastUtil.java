package com.baidu.location.demo.util;

import android.content.Context;
import android.widget.Toast;

public class ToastUtil {

    public static void toastShort(Context context, String desc) {
        Toast.makeText(context, desc, Toast.LENGTH_SHORT).show();
    }

    public static void toastLong(Context context, String desc) {
        Toast.makeText(context, desc, Toast.LENGTH_LONG).show();
    }
}
