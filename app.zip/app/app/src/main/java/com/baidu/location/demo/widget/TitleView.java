package com.baidu.location.demo.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.baidu.location.demo.R;

public class TitleView extends LinearLayout {
    private TextView tv_device_state; //显示的值
    private TextView tv_action_title;  //显示的单位
    private String online;   //名称
    private String title;  //显示的值

    public TitleView(@NonNull Context context) {
        this(context, null);
    }

    public TitleView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TitleView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        LayoutInflater.from(context).inflate(R.layout.view_title, this, true);
        initView(context);
        initAttrs(attrs, context);
        updateValueText();
    }

    private void initAttrs(AttributeSet attrs, Context context) {
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.TitleView);
        online = a.getString(R.styleable.TitleView_online);
        title = a.getString(R.styleable.TitleView_title);
    }

    private void updateValueText() {
        tv_device_state.setText(online);
        tv_action_title.setText(title);
    }

    private void initView(Context context) {
        tv_device_state = findViewById(R.id.tv_device_state);
        tv_action_title = findViewById(R.id.tv_action_title);
    }

    public final void setTitle(CharSequence text) {
        tv_action_title.setText(text);
    }

    public final void setOnline(CharSequence text) {
        tv_device_state.setText(text);
    }
}