package com.baidu.location.demo.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.baidu.location.demo.R;

public class SensorView extends LinearLayout {
    private ImageView iv_src;  //图片路径
    private TextView tv_name;  //显示的名称
    private TextView tv_value; //显示的值
    private TextView tv_unit;  //显示的单位
    private Drawable src;  //图片路径
    private String name;   //名称
    private String value;  //显示的值
    private String unit;   //显示的单位

    public SensorView(@NonNull Context context) {
        this(context, null);
    }

    public SensorView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SensorView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        LayoutInflater.from(context).inflate(R.layout.view_sensor, this, true);
        initView(context);
        initAttrs(attrs, context);
        updateValueText();
    }

    private void initAttrs(AttributeSet attrs, Context context) {
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.SensorView);
        src = a.getDrawable(R.styleable.SensorView_src);
        name = a.getString(R.styleable.SensorView_name);
        value = a.getString(R.styleable.SensorView_value);
        unit = a.getString(R.styleable.SensorView_unit);
    }

    private void updateValueText() {
        iv_src.setImageDrawable(src);
        tv_name.setText(name);
        tv_value.setText(value);
        tv_unit.setText(unit);
    }

    private void initView(Context context) {
        iv_src = findViewById(R.id.iv_sensor_src);
        tv_name = findViewById(R.id.tv_sensor_name);
        tv_value = findViewById(R.id.tv_sensor_value);
        tv_unit = findViewById(R.id.tv_sensor_unit);
    }

    public final void setImageResource(@DrawableRes int resId) {
        iv_src.setImageResource(resId);
    }

    public final void setName(CharSequence text) {
        tv_name.setText(text);
    }

    public final void setText(CharSequence text) {
        tv_value.setText(text);
    }

    public final void setUnit(CharSequence text) {
        tv_unit.setText(text);
    }
}