package com.baidu.location.demo;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.baidu.location.demo.databinding.ActivityMainBinding;
import com.baidu.location.demo.service.Constants;
import com.baidu.location.demo.service.Mqtt3Service;
import com.baidu.location.demo.util.SharedUtil;
import com.baidu.location.demo.widget.ParamSetView;
import com.baidu.location.demo.widget.SwitchView;

import org.json.JSONException;
import org.json.JSONObject;

/**************************************************************************************
 * 创建一个继承自AppCompatActivity的MainActivity类，这是一个标准的Android活动类，用于响应用户的交互
 ***************************************************************************************/
public class MainActivity extends AppCompatActivity {
    private static String action = "com.android.mqtt3";
    private static final String TAG = "hello";
    private Intent mIntent;
    private Mqtt3Service.LocalBinder mBinder; // 声明一个粘合剂对象
    private ActivityMainBinding binding;
    private HandlerThread handlerThread = new HandlerThread("receive_msg");
    private Handler receiveHandler;


    int door_state = 0;
    int fan_state = 0;
    int beep_state = 0;
    int water_state = 0;
    int gas_state = 0;
    int anfang_state = 0;
    int temp_value=0;
    int humi_value=0;
    int gas_value=0;
    int human_value=0;
    int fire_value=0;
    int first_flag=0;
    int gas_threshold=50;
    int wendu_threshold=20;

    String phone_number="-----------";
    int gsm_status = 0;

    private Button btn_phone;

    private static int count=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        try {
            // 获取PackageManager实例
            PackageManager packageManager = getPackageManager();
            // 获取当前应用的ApplicationInfo对象
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(getPackageName(), 0);
            // 获取应用名称
            String appName = (String) packageManager.getApplicationLabel(applicationInfo);
//            binding.title.setTitle(appName);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        SharedUtil sharedUtil = SharedUtil.getIntance(this);
        sharedUtil.write("hello", "1");
        String value = sharedUtil.read("hello", "");
        Log.d(TAG, ">>>>>>>>>>" + value);

        binding.btnDoor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(door_state==0) {
                    door_state=180;
                } else {
                    door_state=0;
                }
            }
        });
        binding.btnPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phone_number = binding.etPhone.getText().toString();
                Toast.makeText(MainActivity.this, "已设置报警电话！", Toast.LENGTH_SHORT).show();
            }
        });

        binding.btnFan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(fan_state==99) {
                    fan_state=0;
                } else {
                    fan_state=99;
                }
            }
        });

        binding.btnGas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(gas_state==1) {
                    gas_state=0;
                } else {
                    gas_state=1;
                }
            }
        });

        binding.btnBeep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(beep_state==1) {
                    beep_state=0;
                } else {
                    beep_state=1;
                }
            }
        });


        binding.btnWater.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(water_state==99) {
                    water_state=0;
                } else {
                    water_state=99;
                }
            }
        });
        binding.btnImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Esp32camActivity.class);
                startActivity(intent);
            }
        });
        binding.btnQitiJia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gas_threshold++;
                binding.tvGasThreshold.setText(gas_threshold+"");
            }
        });

        binding.btnQitiJian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gas_threshold--;
                binding.tvGasThreshold.setText(gas_threshold+"");
            }
        });

        binding.btnTempJia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wendu_threshold++;
                binding.tvTempThreshold.setText(wendu_threshold+"");
            }
        });

        binding.btnTempJian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wendu_threshold--;
                binding.tvTempThreshold.setText(wendu_threshold+"");
            }
        });

        binding.btnAnfang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(anfang_state==1) {
                    anfang_state=0;
                    binding.btnAnfang.setText("开启");
                    Toast.makeText(MainActivity.this, "安防布控关闭", Toast.LENGTH_SHORT).show();
                } else {
                    anfang_state=1;
                    binding.btnAnfang.setText("关闭");
                    Toast.makeText(MainActivity.this, "安防布控开启", Toast.LENGTH_SHORT).show();
                }
            }
        });

        /*************************开启服务*************************/
        mIntent = new Intent(MainActivity.this, Mqtt3Service.class);
        boolean bindFlag = bindService(mIntent, serviceConnection, Context.BIND_AUTO_CREATE);
        /*************************开启服务*************************/

        /*************************通过广播接收的方式从MqttService中接收数据*************************/
        IntentFilter filter = new IntentFilter(MainActivity.action);
        getApplicationContext().registerReceiver(MainActivity_broadcastReceiver, filter);
        Log.d(TAG, "MainActivity start");

        initHandlerThread();
        /*************************通过广播接收的方式从MqttService中接收数据*************************/
    }

    /**
     * 广播消息接收器
     */
    public BroadcastReceiver MainActivity_broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent msgintent) {
            // TODO Auto-generated method stub
            String ReceiverStr = msgintent.getExtras().getString("MQTT_MSG");
            if (ReceiverStr == null) {
                return;
            }
            Message message = Message.obtain(); // 获得默认的消息对象
            message.what = 1;
            message.obj = ReceiverStr;
            receiveHandler.sendMessage(message);
            Log.d(TAG, "MQTT接收消息:<<<<<<" + ReceiverStr);
            Log.d(TAG, "当前所处线程(广播接收):" + Thread.currentThread().getName());
//            binding.title.setOnline("在线");
        }
    };

    private void initHandlerThread() {
        handlerThread.start();
        receiveHandler = new Handler(handlerThread.getLooper()) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                timer_send_task(msg.obj.toString());
                Log.d(TAG, "当前所处线程:" + Thread.currentThread().getName());
                super.handleMessage(msg);
            }
        };
    }

    private void timer_send_task(String msg) {
        try {
            JSONObject data_obj = new JSONObject(msg);
            JSONObject items =data_obj.getJSONObject("items");

            temp_value = items.getJSONObject("temp").getInt("value");
            humi_value = items.getJSONObject("humi").getInt("value");
            gas_value = items.getJSONObject("smoke").getInt("value");
            human_value = items.getJSONObject("human").getInt("value");
            fire_value = items.getJSONObject("fire").getInt("value");

            Log.d(TAG,"ph:" + temp_value);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        new Thread(() -> {
            runOnUiThread(() -> {
                binding.tvTemp.setText(String.valueOf(temp_value));
                binding.tvHumi.setText(String.valueOf(humi_value));
                binding.tvGas.setText(String.valueOf(gas_value));

                if(fire_value==1){
                    binding.tvFire.setText("有");
                } else {
                    binding.tvFire.setText("无");
                }
                if(human_value==1){
                    binding.tvHuman.setText("有人");
                } else {
                    binding.tvHuman.setText("无人");
                }


                //功能6
                if((fire_value==1)&&(human_value==1)) {
                    door_state =180;  //180开门，0关闭
                }
                //功能7
                if(fire_value==1) {
                    water_state=99;  //打开水泵
                }
                //功能5
                if(fire_value==1) {
                    beep_state=1;
                    gsm_status=1;
                    Toast.makeText(this, "发生火灾!", Toast.LENGTH_SHORT).show();
                    Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    vibrator.vibrate(1000); // 1000毫秒的持续时间
                } else {
                    gsm_status=0;
                }
                //功能4
                if(anfang_state==1) {
                    if((temp_value>wendu_threshold)||(gas_value>gas_threshold)){
                        gas_state =1; //关燃气
                        fan_state=99; //开风扇
                        if(count%10==0)
                        {
                            Toast.makeText(this, "环境数据异常，请注意!", Toast.LENGTH_SHORT).show();
                            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                            vibrator.vibrate(1000); // 1000毫秒的持续时间
                        }
                        count++;
                        if(count>10000){
                            count=0;
                        }
                    } else {
                        gas_state =0; //开燃气
                        fan_state=0; //开风扇
                    }
                }

            });
        }).start();

        JSONObject sendItem = new JSONObject();
        try {
            sendItem.put("servo",door_state);
            sendItem.put("fan",fan_state);
            sendItem.put("pump",water_state);
            sendItem.put("relay",gas_state);
            sendItem.put("beep",beep_state);
            sendItem.put("phone",phone_number);
            sendItem.put("gsm",gsm_status);
            gsm_status=0;
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        String SendMsg = sendItem.toString();
        Log.d(TAG, "MQTT发送消息:>>>>>>" + SendMsg);
        mBinder.publish_message(SendMsg);
    }

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBinder = (Mqtt3Service.LocalBinder) service;
            Log.d(TAG, "服务连接成功");
            mBinder.subscribe_message(Constants.sub_topic);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //解除消息接收注册
        unregisterReceiver(MainActivity_broadcastReceiver);
    }
}
