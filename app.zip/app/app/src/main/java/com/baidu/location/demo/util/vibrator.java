package com.baidu.location.demo.util;

import android.content.Context;

public class vibrator {

    private void timer_send_task(Context context) {

    }


}
