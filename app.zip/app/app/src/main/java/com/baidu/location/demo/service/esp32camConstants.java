package com.baidu.location.demo.service;

public class esp32camConstants {
    //测试账号:broker.emqx.io,1883
    public static final String client_id = "k1s55VMU5YV.app_dev|securemode=2,signmethod=hmacsha256,timestamp=1728636772638|";//客户端ID，一般以客户端唯一标识符表示
    public static final String host = "mqtt.xiaotongren.top";//服务器地址
    public static final String port = "1883";//服务器端口号
    public static final String username = "student";//用户名
    public static final String password = "12345678";//密码
    public static final String pub_topic = "/k1s55VMU5YV/app_dev/user/update";//发布主题
    public static final String sub_topic = "/student/02896ysgsg/media/send_img";//订阅主题
}
