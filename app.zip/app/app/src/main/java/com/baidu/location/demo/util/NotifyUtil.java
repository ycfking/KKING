package com.baidu.location.demo.util;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.Toast;

import com.baidu.location.demo.MainActivity;
import com.baidu.location.demo.R;

public class NotifyUtil {

    private String mChannelId = "0"; // 通知渠道的编号
    private String mChannelName; // 通知渠道的名称
    private int mImportance; // 通知渠道的级别


    private int[] importanceTypeArray = {
            NotificationManager.IMPORTANCE_NONE,
            NotificationManager.IMPORTANCE_MIN,
            NotificationManager.IMPORTANCE_LOW,
            NotificationManager.IMPORTANCE_DEFAULT,
            NotificationManager.IMPORTANCE_HIGH,
            NotificationManager.IMPORTANCE_MAX};

    private String[] importanceDescArray = {
            "不重要",   // 无通知
            "最小级别", // 通知栏折叠，无提示声音，无锁屏通知
            "有点重要", // 通知栏展开，无提示声音，有锁屏通知
            "一般重要", // 通知栏展开，有提示声音，有锁屏通知
            "非常重要", // 通知栏展开，有提示声音，有锁屏通知，在屏幕顶部短暂悬浮（有的手机需要在设置页面开启横幅）
            "最高级别"  // 通知栏展开，有提示声音，有锁屏通知，在屏幕顶部短暂悬浮（有的手机需要在设置页面开启横幅）
    };

    public void createNotifyChannel(Context ctx, String channelId, String channelName, int importance) {
        // 从系统服务中获取通知管理器
        NotificationManager notifyMgr = (NotificationManager)
                ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notifyMgr.getNotificationChannel(channelId) == null) { // 已经存在指定编号的通知渠道
            // 创建指定编号、指定名称、指定级别的通知渠道
            NotificationChannel channel = new NotificationChannel(channelId, channelName, importance);
            channel.setSound(null, null); // 设置推送通知之时的铃声。null表示静音推送
            channel.enableLights(true); // 通知渠道是否让呼吸灯闪烁
            channel.enableVibration(true); // 通知渠道是否让手机震动
            channel.setShowBadge(true); // 通知渠道是否在应用图标的右上角展示小红点
            // VISIBILITY_PUBLIC显示所有通知信息，VISIBILITY_PRIVATE只显示通知标题不显示通知内容，VISIBILITY_SECRET不显示任何通知信息
            channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE); // 设置锁屏时候的可见性
            channel.setImportance(importance); // 设置通知渠道的重要性级别
            notifyMgr.createNotificationChannel(channel); // 创建指定的通知渠道
        }
    }

    // 发送指定渠道的通知消息（包括消息标题和消息内容）
    public void sendChannelNotify(Context context, String title, String message) {

        mImportance = importanceTypeArray[5];
        mChannelName = importanceDescArray[5];

        // 创建一个跳转到活动页面的意图
        Intent clickIntent = new Intent(context, MainActivity.class);
        // 创建一个用于页面跳转的延迟意图
        PendingIntent contentIntent = PendingIntent.getActivity(context,
                R.string.app_name, clickIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        // 创建一个通知消息的建造器
        Notification.Builder builder = new Notification.Builder(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Android 8.0开始必须给每个通知分配对应的渠道
            builder = new Notification.Builder(context, mChannelId);
        }
        builder.setContentIntent(contentIntent)                // 设置内容的点击意图
                .setAutoCancel(true)                           // 点击通知栏后是否自动清除该通知
                .setSmallIcon(R.mipmap.ic_launcher)            // 设置应用名称左边的小图标
                .setContentTitle(title)                        // 设置通知栏里面的标题文本
                .setContentText(message);                      // 设置通知栏里面的内容文本
        Notification notify = builder.build();                 // 根据通知建造器构建一个通知对象
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotifyChannel(context, mChannelId, mChannelName, mImportance);
        }
        // 从系统服务中获取通知管理器
        NotificationManager notifyMgr = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        // 使用通知管理器推送通知，然后在手机的通知栏就会看到该消息，多条通知需要指定不同的通知编号
        notifyMgr.notify(Integer.parseInt(mChannelId), notify);
        if (mImportance != NotificationManager.IMPORTANCE_NONE) {
            Toast.makeText(context, "已发送渠道消息", Toast.LENGTH_SHORT).show();
        }
    }
}
