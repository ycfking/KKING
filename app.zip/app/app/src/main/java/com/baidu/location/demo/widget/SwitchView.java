package com.baidu.location.demo.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.baidu.location.demo.R;

public class SwitchView extends FrameLayout {
    private ImageView iv_src;  //图片路径
    private TextView tv_name;  //显示的名称
    private Switch sw_state; //显示的值
    private Drawable src;  //图片路径
    private String name;   //名称
    private OnCheckedChangeListener listener;

    public SwitchView(@NonNull Context context) {
        this(context, null);
    }

    public SwitchView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SwitchView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        LayoutInflater.from(context).inflate(R.layout.view_switch, this, true);
        initView(context);
        initAttrs(attrs, context);
        setChecked();
    }

    private void initAttrs(AttributeSet attrs, Context context) {
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.SwitchView);
        src = a.getDrawable(R.styleable.SwitchView_src);
        name = a.getString(R.styleable.SwitchView_name);

        updateValueText();
    }

    private void setChecked() {
        sw_state.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (!buttonView.isPressed()) {
                    return;
                }
                listener.onCheckedChanged(SwitchView.this, isChecked);
                updateValueText();
            }
        });
    }

    private void updateValueText() {
        iv_src.setImageDrawable(src);
        tv_name.setText(name);
    }

    private void initView(Context context) {
        iv_src = findViewById(R.id.iv_switch_src);
        sw_state = findViewById(R.id.sw_switch_state);
        tv_name = findViewById(R.id.tv_switch_name);
    }

    public final void setImageResource(@DrawableRes int resId) {
        iv_src.setImageResource(resId);
    }

    public final void setName(CharSequence text) {
        tv_name.setText(text);
    }

    public void setOnValueChangeListener(OnCheckedChangeListener listener) {
        this.listener = listener;
    }

    public interface OnCheckedChangeListener {
        void onCheckedChanged(SwitchView SwitchView, boolean isChecked);
    }
}