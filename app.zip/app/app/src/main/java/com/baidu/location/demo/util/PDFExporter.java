package com.baidu.location.demo.util;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class PDFExporter {

    public void exportDataToPDF(Context context, String dbName, String tableName, String pdfPath) {
        SQLiteOpenHelper dbHelper = new DatabaseHelper(context, dbName);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(tableName, null, null, null, null, null, null);
        List<String[]> dataList = convertCursorToList(cursor);

        Document document = new Document();
        try {
            File file = new File(pdfPath);
            FileOutputStream fOut = new FileOutputStream(file);
            PdfWriter.getInstance(document, fOut);

            document.open();
            for (String[] data : dataList) {
                Paragraph paragraph = new Paragraph();
                for (String columnData : data) {
                    paragraph.add(columnData + "\t");
                }
                document.add(paragraph);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            document.close();
            cursor.close();
            db.close();
        }
    }

    private List<String[]> convertCursorToList(Cursor cursor) {
        List<String[]> list = new ArrayList<>();
        while (cursor.moveToNext()) {
            String[] row = new String[cursor.getColumnCount()];
            for (int i = 0; i < cursor.getColumnCount(); i++) {
                row[i] = cursor.getString(i);
            }
            list.add(row);
        }
        return list;
    }
}