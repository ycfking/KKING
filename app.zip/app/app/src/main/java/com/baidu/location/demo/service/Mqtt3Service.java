package com.baidu.location.demo.service;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class Mqtt3Service extends Service {
    public static final String TAG = "hello";
    private static String action = "com.android.mqtt3";
    private static MqttClient mqttClient;//客户端
    static MqttConnectOptions mqttConnectOptions;
    private final IBinder mBinder = new LocalBinder(); // 创建一个粘合剂对象

    private final Handler handler = new Handler();

    // 定义一个当前服务的粘合剂，用于将该服务黏到活动页面的进程中
    public class LocalBinder extends Binder {
        public Mqtt3Service getService() {
            return Mqtt3Service.this;
        }

        /**
         * 订阅特定的主题
         *
         * @param topic mqtt主题
         */
        public void subscribe_message(String topic) {
            try {
                mqttClient.subscribe(topic, 0);
            } catch (MqttException e) {
                e.printStackTrace();
            }
        }

        /**
         * 发布数据
         *
         * @param payload 消息载荷
         */
        public void publish_message(String payload) {
            try {
                if (mqttClient.isConnected() == false) {
                    mqttClient.connect(mqttConnectOptions);//连接服务器,连接不上会阻塞在这
                }
                MqttMessage message = new MqttMessage();
                message.setPayload(payload.getBytes());
                message.setQos(0);
                mqttClient.publish(Constants.pub_topic, message);
            } catch (MqttException e) {
                Log.e(TAG, e.toString());
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public IBinder onBind(Intent intent) {
        init();
        Log.d(TAG, "开启:onBind");
        return mBinder;
    }

    /**
     * 初始化
     */
    private void init() {

        Log.d(TAG, "mqtt init");
        String host = "tcp://" + Constants.host + ":" + Constants.port;//服务器地址（协议+地址+端口号）

        mqttConnectOptions = new MqttConnectOptions();
        mqttConnectOptions.setUserName(Constants.username);
        mqttConnectOptions.setPassword(Constants.password.toCharArray());
        mqttConnectOptions.setKeepAliveInterval(60);
        mqttConnectOptions.setConnectionTimeout(10);
        try {
            //(1)主机地址(2)客户端ID,一般以客户端唯一标识符(不能够和其它客户端重名)(3)最后一个参数是指数据保存在内存
            mqttClient = new MqttClient(host, Constants.client_id, new MemoryPersistence());
            mqttClient.setCallback(mqttCallback);
        } catch (MqttException e) {
            e.printStackTrace();
        }

        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (mqttClient.isConnected() == false) {
                        mqttClient.connect(mqttConnectOptions);//连接服务器,连接不上会阻塞在这
                        Log.d(TAG, "连接成功");
                    }
                } catch (MqttException e) {
                    Log.d(TAG, "连接失败");
                    e.printStackTrace();
                }
                try {
                    mqttClient.subscribe(Constants.sub_topic, 0);
                } catch (MqttException e) {
                    e.printStackTrace();
                }
                handler.postDelayed(this, 10000);
            }
        });
    }


    private MqttCallback mqttCallback = new MqttCallback() {

        @Override
        public void connectionLost(Throwable cause) {

        }

        @Override
        public void messageArrived(String topic, MqttMessage message) throws Exception {
            Intent intent = new Intent(action);
            Bundle bundle = new Bundle();
            bundle.putString("MQTT_MSG", new String(message.getPayload()));
            intent.putExtras(bundle);
            sendBroadcast(intent);
            Log.d(TAG, "mqtt服务接收数据:" + new String(message.getPayload()));
        }

        @Override
        public void deliveryComplete(IMqttDeliveryToken token) {

        }
    };

    @Override
    public void onDestroy() {
        try {
            mqttClient.disconnect(); //断开连接
            Log.d(TAG, "断开MQTT连接！！！");
        } catch (MqttException e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }
}